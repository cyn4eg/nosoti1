from django.views.generic import ListView, DetailView, UpdateView, DeleteView, CreateView
from django.shortcuts import render
from django.core.paginator import Paginator
from .models import Post
from .filters import PostFilter, AuthorSearch


class PostList(ListView):
    model = Post  # указываем модель, объекты которой мы будем выводить
    template_name = 'post_list.html'
    context_object_name = 'posts'
    ordering = ['-dataCreation']
    paginate_by = 1
    def get_filter(self):
        return PostFilter(self.request.GET, queryset=super().get_queryset())
    def get_queryset(self):
        return self.get_filter().qs

    def get_context_data(self, *args, **kwargs):
        return {
            **super().get_context_data(*args, **kwargs),
            "filter":self.get_filter(),
        }

    def post(self, request, *args, **kwargs):
        # берём значения для нового товара из POST-запроса отправленного на сервер
        author = request.POST['author']
        title = request.POST['title']
        dataCreation = request.POST['dataCreation']

        post = Post(author=author, title=title,
                          dataCreation=dataCreation)  # создаём новый товар и сохраняем
        post.save()
        return super().get(request, *args, **kwargs)

class PostDetail(DetailView):
    model = Post  # модель всё та же
    template_name = 'posts.html'  # название шаблона
    context_object_name = 'post'  # название объекта


def author_search(request):
    f = AuthorSearch(request.GET, queryset=Post.objects.all())
    return render(request, 'search.html', {'filter': f})



class NewsUpdateView(UpdateView):
    template_name = 'news_update.html'
    form_class = Post

    def get_object(self, **kwargs):
        id = self.kwargs.get('pk')
        return Post.objects.get(pk=id)








from django_filters import FilterSet, ModelChoiceFilter
from .models import Post

class PostFilter(FilterSet):
    class Meta:
        model = Post
        fields = {
            'author',
            'dataCreation',
            'title',

        }

class AuthorSearch(FilterSet):
    author = ModelChoiceFilter(queryset=Post.objects.all())

    class Meta:
        model = Post
        fields = {
            'author',
            'dataCreation',
        }

